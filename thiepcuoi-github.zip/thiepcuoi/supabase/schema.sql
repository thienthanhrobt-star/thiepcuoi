-- Chạy toàn bộ file này trong Supabase > SQL Editor
create table profiles (
  id uuid primary key references auth.users on delete cascade,
  full_name text, role text not null default 'user' check (role in ('user','admin')),
  created_at timestamptz default now());
create table templates (
  id uuid primary key default gen_random_uuid(), name text not null, tag text,
  theme jsonb not null, active boolean default true, created_at timestamptz default now());
create table cards (
  id uuid primary key default gen_random_uuid(),
  owner uuid not null references profiles(id) on delete cascade,
  slug text unique not null default substr(md5(random()::text || clock_timestamp()::text),1,8),
  template text not null, data jsonb not null,
  created_at timestamptz default now(), updated_at timestamptz default now());
create table rsvps (
  id uuid primary key default gen_random_uuid(),
  card_id uuid not null references cards(id) on delete cascade,
  guest_name text not null, attending boolean not null, guests int default 1, wish text,
  created_at timestamptz default now());

create function is_admin() returns boolean language sql security definer stable as
$$ select exists(select 1 from profiles where id = auth.uid() and role = 'admin') $$;

-- Tự tạo hồ sơ khi có người đăng ký
create function handle_new_user() returns trigger language plpgsql security definer as $$
begin insert into profiles(id, full_name) values (new.id, new.raw_user_meta_data->>'full_name'); return new; end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function handle_new_user();

alter table profiles enable row level security;
alter table templates enable row level security;
alter table cards enable row level security;
alter table rsvps enable row level security;

create policy "xem hồ sơ của mình hoặc admin" on profiles for select using (id = auth.uid() or is_admin());
create policy "sửa tên của mình" on profiles for update using (id = auth.uid()) with check (id = auth.uid() and role = (select role from profiles where id = auth.uid()));
create policy "ai cũng xem mẫu đang bật" on templates for select using (active or is_admin());
create policy "admin quản lý mẫu" on templates for all using (is_admin()) with check (is_admin());
create policy "chủ thiệp toàn quyền" on cards for all using (owner = auth.uid() or is_admin()) with check (owner = auth.uid() or is_admin());
create policy "chủ thiệp xem RSVP" on rsvps for select using (exists(select 1 from cards c where c.id = card_id and (c.owner = auth.uid() or is_admin())));
create policy "chủ thiệp xóa RSVP" on rsvps for delete using (exists(select 1 from cards c where c.id = card_id and c.owner = auth.uid()));

-- Khách (chưa đăng nhập) mở thiệp và gửi xác nhận qua 2 hàm này
create function get_card(p_slug text) returns jsonb language sql security definer stable as
$$ select jsonb_build_object('template', template, 'data', data, 'slug', slug) from cards where slug = p_slug $$;
create function submit_rsvp(p_slug text, p_name text, p_attending boolean, p_guests int, p_wish text)
returns void language plpgsql security definer as $$
declare cid uuid;
begin
  select id into cid from cards where slug = p_slug;
  if cid is null then raise exception 'not found'; end if;
  insert into rsvps(card_id, guest_name, attending, guests, wish)
  values (cid, left(trim(p_name),100), p_attending, greatest(1,least(coalesce(p_guests,1),20)), left(p_wish,500));
end $$;
grant execute on function get_card(text), submit_rsvp(text,text,boolean,int,text) to anon, authenticated;
