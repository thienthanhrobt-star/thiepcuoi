-- Chạy SAU schema.sql (Supabase > SQL Editor)
alter table profiles add column if not exists email text;
alter table profiles add column if not exists status text not null default 'active' check (status in ('active','blocked'));
alter table templates add column if not exists preview_url text;
update profiles p set email = u.email from auth.users u where u.id = p.id;

create or replace function handle_new_user() returns trigger language plpgsql security definer as $$
begin insert into profiles(id, full_name, email) values (new.id, new.raw_user_meta_data->>'full_name', new.email); return new; end $$;

create function is_active() returns boolean language sql security definer stable as
$$ select coalesce((select status = 'active' from profiles where id = auth.uid()), false) $$;

create policy "admin sửa hồ sơ" on profiles for update using (is_admin()) with check (is_admin());

-- Tài khoản bị khóa không thao tác được với thiệp của mình
drop policy "chủ thiệp toàn quyền" on cards;
create policy "chủ thiệp toàn quyền" on cards for all
  using ((owner = auth.uid() and is_active()) or is_admin())
  with check ((owner = auth.uid() and is_active()) or is_admin());

-- Kho ảnh xem trước mẫu thiệp
insert into storage.buckets (id, name, public) values ('template-previews','template-previews', true) on conflict do nothing;
create policy "xem ảnh mẫu" on storage.objects for select using (bucket_id = 'template-previews');
create policy "admin tải ảnh mẫu" on storage.objects for insert with check (bucket_id = 'template-previews' and is_admin());
create policy "admin xóa ảnh mẫu" on storage.objects for delete using (bucket_id = 'template-previews' and is_admin());
