'use client'
import { useState } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import Link from 'next/link'
import { supabaseBrowser } from '@/lib/supabase/client'

const vi = (m: string) =>
  m.includes('Invalid login') ? 'Email hoặc mật khẩu không đúng.' :
  m.includes('already registered') ? 'Email này đã được đăng ký.' :
  m.includes('not confirmed') ? 'Bạn cần xác nhận email trước khi đăng nhập.' :
  m.includes('at least') ? 'Mật khẩu cần ít nhất 6 ký tự.' : m

export default function AuthForm({ mode }: { mode: 'signup' | 'login' }) {
  const router = useRouter()
  const params = useSearchParams()
  const rawNext = params.get('next') || '/dashboard'
  const next = rawNext.startsWith('/') && !rawNext.startsWith('//') ? rawNext : '/dashboard'
  const [name, setName] = useState(''); const [email, setEmail] = useState(''); const [pw, setPw] = useState('')
  const [err, setErr] = useState(''); const [info, setInfo] = useState(''); const [busy, setBusy] = useState(false)
  const sb = supabaseBrowser()
  const cb = () => `${location.origin}/auth/callback?next=${encodeURIComponent(next)}`

  async function submit(e: React.FormEvent) {
    e.preventDefault(); setErr(''); setInfo(''); setBusy(true)
    if (mode === 'signup') {
      const { data, error } = await sb.auth.signUp({ email, password: pw, options: { data: { full_name: name }, emailRedirectTo: cb() } })
      if (error) setErr(vi(error.message))
      else if (data.session) router.replace(next)
      else setInfo('Đã gửi email xác nhận. Hãy mở email và bấm vào liên kết để kích hoạt tài khoản.')
    } else {
      const { error } = await sb.auth.signInWithPassword({ email, password: pw })
      if (error) setErr(vi(error.message)); else { router.replace(next); router.refresh() }
    }
    setBusy(false)
  }
  async function google() { await sb.auth.signInWithOAuth({ provider: 'google', options: { redirectTo: cb() } }) }
  async function reset() {
    if (!email) return setErr('Nhập email của bạn trước, rồi bấm “Quên mật khẩu”.')
    const { error } = await sb.auth.resetPasswordForEmail(email, { redirectTo: `${location.origin}/auth/callback?next=/dashboard` })
    error ? setErr(vi(error.message)) : setInfo('Đã gửi email đặt lại mật khẩu.')
  }
  return (
    <form onSubmit={submit} className="card auth">
      <h1>{mode === 'signup' ? 'Tạo tài khoản' : 'Đăng nhập'}</h1>
      <button type="button" className="btn o" onClick={google}>Tiếp tục với Google</button>
      <div className="or">hoặc</div>
      {mode === 'signup' && (<><label>Họ tên</label><input value={name} onChange={e => setName(e.target.value)} required /></>)}
      <label>Email</label><input type="email" value={email} onChange={e => setEmail(e.target.value)} required />
      <label>Mật khẩu</label><input type="password" minLength={6} value={pw} onChange={e => setPw(e.target.value)} required />
      {err && <p className="err">{err}</p>}{info && <p className="ok">{info}</p>}
      <button className="btn" disabled={busy}>{busy ? 'Đang xử lý…' : mode === 'signup' ? 'Đăng ký' : 'Đăng nhập'}</button>
      {mode === 'login' && <p><a href="#" onClick={e => { e.preventDefault(); reset() }}>Quên mật khẩu?</a></p>}
      <p>{mode === 'signup' ? <>Đã có tài khoản? <Link href="/dang-nhap">Đăng nhập</Link></> : <>Chưa có tài khoản? <Link href="/dang-ky">Đăng ký miễn phí</Link></>}</p>
    </form>
  )
}
