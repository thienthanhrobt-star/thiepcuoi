'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { supabaseBrowser } from '@/lib/supabase/client'

const FONTS = ['Dancing Script', 'Pacifico', 'Lobster', 'Cormorant Garamond', 'Playfair Display', 'Montserrat']
const init = { name: '', tag: '', bg: '#fdf2f4', ink: '#3a2a2c', ac: '#c0506a', sf: '#ffffff', nf: FONTS[0], hf: FONTS[4], lay: 'center', fx: '❀', pat: 'none', up: false, xi: false }

export default function TemplateForm() {
  const [t, setT] = useState<any>(init)
  const [img, setImg] = useState<File | null>(null)
  const [msg, setMsg] = useState(''); const [busy, setBusy] = useState(false)
  const router = useRouter()
  const set = (k: string, v: any) => setT((o: any) => ({ ...o, [k]: v }))

  async function importJson(f?: File) {
    if (!f) return
    try {
      const j = JSON.parse(await f.text()); const q = (s: string) => String(s ?? '').replace(/['"]/g, '')
      setT((o: any) => ({ ...o, ...j, name: j.name ?? j.n ?? o.name, nf: q(j.nf ?? o.nf), hf: q(j.hf ?? o.hf) })); setMsg('Đã nạp thông tin từ file JSON.')
    } catch { setMsg('File JSON không hợp lệ.') }
  }
  async function submit(e: React.FormEvent) {
    e.preventDefault(); if (!t.name.trim()) return setMsg('Hãy nhập tên mẫu.')
    setBusy(true); setMsg(''); const sb = supabaseBrowser(); let preview_url: string | null = null
    if (img) {
      const path = `${crypto.randomUUID()}.${(img.name.split('.').pop() || 'png').toLowerCase()}`
      const up = await sb.storage.from('template-previews').upload(path, img)
      if (up.error) { setBusy(false); return setMsg('Không tải được ảnh: ' + up.error.message) }
      preview_url = sb.storage.from('template-previews').getPublicUrl(path).data.publicUrl
    }
    const { name, tag, ...theme } = t
    const { error } = await sb.from('templates').insert({ name: name.trim(), tag: tag.trim() || 'Khác', theme, preview_url, active: true })
    setBusy(false)
    if (error) return setMsg('Không lưu được: ' + error.message)
    setT(init); setImg(null); setMsg('Đã thêm mẫu mới.'); router.refresh()
  }
  const sel = (k: string, label: string, opts: string[]) => (<div><label>{label}</label><select value={t[k]} onChange={e => set(k, e.target.value)}>{opts.map(o => <option key={o}>{o}</option>)}</select></div>)
  const col = (k: string, label: string) => (<div><label>{label}</label><input type="color" value={t[k]} onChange={e => set(k, e.target.value)} /></div>)
  return (
    <form onSubmit={submit} className="card auth" style={{ maxWidth: 'none' }}>
      <h3 style={{ margin: 0 }}>Tải lên mẫu thiệp mới</h3>
      <label>Nạp nhanh từ file JSON (xem docs/mau-thiep-vi-du.json)</label>
      <input type="file" accept="application/json,.json" onChange={e => importJson(e.target.files?.[0])} />
      <div className="row"><div><label>Tên mẫu</label><input value={t.name} onChange={e => set('name', e.target.value)} /></div><div><label>Phong cách</label><input value={t.tag} placeholder="Sang trọng, Tối giản…" onChange={e => set('tag', e.target.value)} /></div></div>
      <div className="row4">{col('bg', 'Màu nền')}{col('ink', 'Màu chữ')}{col('ac', 'Màu nhấn')}{col('sf', 'Màu khung')}</div>
      <div className="row4">{sel('lay', 'Bố cục', ['center', 'arch', 'frame', 'split'])}{sel('fx', 'Hiệu ứng rơi', ['❀', '❦', '✦', '♥', '✧'])}{sel('nf', 'Phông tên', FONTS)}{sel('hf', 'Phông tiêu đề', FONTS)}</div>
      <div className="row4">{sel('pat', 'Họa tiết nền', ['none', 'dots', 'lines'])}
        <div><label>In hoa tên</label><input type="checkbox" checked={t.up} onChange={e => set('up', e.target.checked)} /></div>
        <div><label>Chữ 囍</label><input type="checkbox" checked={t.xi} onChange={e => set('xi', e.target.checked)} /></div></div>
      <div className="swatch" style={{ background: t.bg, color: t.ink, borderColor: t.ac }}>{t.name || 'Xem trước màu'} <span style={{ color: t.ac }}>{t.fx}</span></div>
      <label>Ảnh xem trước (tùy chọn, tỉ lệ dọc 9:16)</label>
      <input type="file" accept="image/*" onChange={e => setImg(e.target.files?.[0] ?? null)} />
      {msg && <p className="ok">{msg}</p>}
      <button className="btn" disabled={busy}>{busy ? 'Đang lưu…' : 'Thêm mẫu'}</button>
    </form>
  )
}
