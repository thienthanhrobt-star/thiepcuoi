import { createServerClient } from '@supabase/ssr'
import { NextResponse, type NextRequest } from 'next/server'
export async function middleware(req: NextRequest) {
  let res = NextResponse.next({ request: req })
  const sb = createServerClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!, {
    cookies: {
      getAll: () => req.cookies.getAll(),
      setAll: (list) => {
        list.forEach(({ name, value }) => req.cookies.set(name, value))
        res = NextResponse.next({ request: req })
        list.forEach(({ name, value, options }) => res.cookies.set(name, value, options))
      },
    },
  })
  const { data: { user } } = await sb.auth.getUser()
  const p = req.nextUrl.pathname
  if (!user && (p.startsWith('/dashboard') || p.startsWith('/admin'))) {
    const u = req.nextUrl.clone(); u.pathname = '/dang-nhap'; u.search = ''; u.searchParams.set('next', p)
    return NextResponse.redirect(u)
  }
  if (user && (p === '/dang-nhap' || p === '/dang-ky')) {
    const u = req.nextUrl.clone(); u.pathname = '/dashboard'; u.search = ''
    return NextResponse.redirect(u)
  }
  return res
}
export const config = { matcher: ['/dashboard/:path*', '/admin/:path*', '/dang-nhap', '/dang-ky'] }
