import { redirect } from 'next/navigation'
import { supabaseServer } from '@/lib/supabase/server'
export async function requireAdmin() {
  const sb = await supabaseServer()
  const { data: { user } } = await sb.auth.getUser()
  if (!user) redirect('/dang-nhap')
  const { data: p } = await sb.from('profiles').select('role,status').eq('id', user.id).single()
  if (p?.role !== 'admin' || p?.status === 'blocked') redirect('/dashboard')
  return { sb, user }
}
