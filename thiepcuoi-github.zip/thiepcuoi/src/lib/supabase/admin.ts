import { createClient } from '@supabase/supabase-js'
// Chỉ gọi từ server actions / server components. Khóa service role bỏ qua RLS.
export const supabaseAdmin = () =>
  createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, { auth: { persistSession: false } })
