import { Suspense } from 'react'
import AuthForm from '@/components/AuthForm'
export default function Page() { return <main className="wrap"><Suspense><AuthForm mode="login" /></Suspense></main> }
