import { NextResponse } from 'next/server'
import { supabaseServer } from '@/lib/supabase/server'
export async function GET(req: Request) {
  const { searchParams, origin } = new URL(req.url)
  const code = searchParams.get('code'); const n = searchParams.get('next') || '/dashboard'
  const next = n.startsWith('/') && !n.startsWith('//') ? n : '/dashboard'
  if (code) { const sb = await supabaseServer(); await sb.auth.exchangeCodeForSession(code) }
  return NextResponse.redirect(origin + next)
}
