import Link from 'next/link'
import { supabaseServer } from '@/lib/supabase/server'
export default async function Dashboard() {
  const sb = await supabaseServer()
  const { data: { user } } = await sb.auth.getUser()
  const { data: profile } = await sb.from('profiles').select('full_name, role, status').eq('id', user!.id).single()
  const { data: cards } = await sb.from('cards').select('id, slug, data, rsvps(count)').order('created_at', { ascending: false })
  if (profile?.status === 'blocked') return (<main className="wrap"><div className="card"><b>Tài khoản của bạn đã bị khóa.</b><p>Vui lòng liên hệ quản trị viên.</p><form action="/auth/signout" method="post"><button className="btn o">Đăng xuất</button></form></div></main>)
  return (
    <main className="wrap">
      <nav className="nav"><Link href="/"><b>Thiệp Cưới</b></Link>
        <form action="/auth/signout" method="post">
          <span>{profile?.full_name || user?.email}</span>{' '}
          {profile?.role === 'admin' && <Link className="btn o" href="/admin">Quản trị</Link>}{' '}
          <button className="btn o">Đăng xuất</button>
        </form></nav>
      <h2>Thiệp của tôi</h2>
      {cards?.length ? cards.map((c: any) => (
        <div className="card" key={c.id}><b>{c.data?.groom} &amp; {c.data?.bride}</b>
          <div>{c.rsvps?.[0]?.count ?? 0} phản hồi · <a href={`/t/${c.slug}`}>/t/{c.slug}</a></div></div>
      )) : <p>Bạn chưa có thiệp nào. (Trình tạo thiệp sẽ được thêm ở bước tiếp theo.)</p>}
    </main>
  )
}
