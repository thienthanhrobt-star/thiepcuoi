import './globals.css'
export const metadata = { title: 'Thiệp Cưới – Tạo thiệp cưới online', description: 'Tạo thiệp cưới online trong 5 phút.' }
export default function Root({ children }: { children: React.ReactNode }) {
  return <html lang="vi"><body>{children}</body></html>
}
