import { requireAdmin } from '@/lib/auth'
export default async function Overview() {
  const { sb } = await requireAdmin()
  const count = async (t: string, f?: (q: any) => any) => {
    let q: any = sb.from(t).select('*', { count: 'exact', head: true }); if (f) q = f(q)
    return (await q).count ?? 0
  }
  const [users, blocked, cards, rsvps, tpls] = await Promise.all([
    count('profiles'), count('profiles', q => q.eq('status', 'blocked')), count('cards'), count('rsvps'), count('templates'),
  ])
  const items: [string, number][] = [['Tài khoản', users], ['Đang bị khóa', blocked], ['Thiệp', cards], ['Phản hồi RSVP', rsvps], ['Mẫu thiệp tải lên', tpls]]
  return <div className="grid">{items.map(([l, n]) => <div className="card" key={l}><div className="tag">{l}</div><b style={{ fontSize: 28 }}>{n}</b></div>)}</div>
}
