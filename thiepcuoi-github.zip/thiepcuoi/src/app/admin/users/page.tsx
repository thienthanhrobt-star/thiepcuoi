import { requireAdmin } from '@/lib/auth'
import { setRole, setStatus, deleteUser } from './actions'

export default async function Users({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  const { q = '' } = await searchParams
  const { sb, user } = await requireAdmin()
  const { data: profiles } = await sb.from('profiles').select('id, full_name, email, role, status, created_at').order('created_at', { ascending: false })
  const { data: cards } = await sb.from('cards').select('owner')
  const n: Record<string, number> = {}; cards?.forEach(c => { n[c.owner] = (n[c.owner] || 0) + 1 })
  const k = q.trim().toLowerCase()
  const rows = (profiles ?? []).filter(p => !k || `${p.full_name} ${p.email}`.toLowerCase().includes(k))
  return (
    <>
      <form className="row" style={{ marginBottom: 12 }}><input name="q" defaultValue={q} placeholder="Tìm theo tên hoặc email…" /><button className="btn o">Tìm</button></form>
      <div style={{ overflowX: 'auto' }}><table>
        <thead><tr><th>Tài khoản</th><th>Quyền</th><th>Trạng thái</th><th>Số thiệp</th><th>Ngày tạo</th><th></th></tr></thead>
        <tbody>{rows.map(p => (
          <tr key={p.id}>
            <td><b>{p.full_name || '(chưa đặt tên)'}</b><div className="tag">{p.email}</div></td>
            <td>{p.role === 'admin' ? 'Admin' : 'Người dùng'}</td>
            <td>{p.status === 'blocked' ? '🔒 Bị khóa' : 'Hoạt động'}</td>
            <td>{n[p.id] ?? 0}</td>
            <td>{new Date(p.created_at).toLocaleDateString('vi-VN')}</td>
            <td>{p.id === user.id ? <span className="tag">Bạn</span> : (
              <div className="acts">
                <form action={setRole}><input type="hidden" name="id" value={p.id} /><input type="hidden" name="role" value={p.role === 'admin' ? 'user' : 'admin'} /><button className="btn o sm">{p.role === 'admin' ? 'Bỏ admin' : 'Làm admin'}</button></form>
                <form action={setStatus}><input type="hidden" name="id" value={p.id} /><input type="hidden" name="status" value={p.status === 'blocked' ? 'active' : 'blocked'} /><button className="btn o sm">{p.status === 'blocked' ? 'Mở khóa' : 'Khóa'}</button></form>
                <form action={deleteUser}><input type="hidden" name="id" value={p.id} /><button className="btn o sm danger">Xóa</button></form>
              </div>)}</td>
          </tr>))}
        </tbody></table></div>
      <p className="tag">“Xóa” sẽ xóa vĩnh viễn tài khoản cùng toàn bộ thiệp và phản hồi của người đó.</p>
    </>
  )
}
