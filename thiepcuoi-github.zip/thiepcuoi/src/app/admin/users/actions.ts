'use server'
import { revalidatePath } from 'next/cache'
import { requireAdmin } from '@/lib/auth'
import { supabaseAdmin } from '@/lib/supabase/admin'

export async function setRole(fd: FormData) {
  const { sb, user } = await requireAdmin()
  const id = String(fd.get('id')), role = fd.get('role') === 'admin' ? 'admin' : 'user'
  if (id === user.id) return // không tự đổi quyền của chính mình
  await sb.from('profiles').update({ role }).eq('id', id)
  revalidatePath('/admin/users')
}
export async function setStatus(fd: FormData) {
  const { sb, user } = await requireAdmin()
  const id = String(fd.get('id')), status = fd.get('status') === 'blocked' ? 'blocked' : 'active'
  if (id === user.id) return
  await sb.from('profiles').update({ status }).eq('id', id)
  revalidatePath('/admin/users')
}
export async function deleteUser(fd: FormData) {
  const { user } = await requireAdmin()
  const id = String(fd.get('id'))
  if (id === user.id) return
  await supabaseAdmin().auth.admin.deleteUser(id) // xóa kéo theo hồ sơ, thiệp và RSVP
  revalidatePath('/admin/users')
}
