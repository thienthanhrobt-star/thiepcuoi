'use server'
import { revalidatePath } from 'next/cache'
import { requireAdmin } from '@/lib/auth'
export async function toggleTemplate(fd: FormData) {
  const { sb } = await requireAdmin()
  await sb.from('templates').update({ active: fd.get('active') === 'true' }).eq('id', String(fd.get('id')))
  revalidatePath('/admin/templates')
}
export async function deleteTemplate(fd: FormData) {
  const { sb } = await requireAdmin()
  await sb.from('templates').delete().eq('id', String(fd.get('id')))
  revalidatePath('/admin/templates')
}
