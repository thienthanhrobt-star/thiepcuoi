import { requireAdmin } from '@/lib/auth'
import TemplateForm from '@/components/TemplateForm'
import { toggleTemplate, deleteTemplate } from './actions'

export default async function Templates() {
  const { sb } = await requireAdmin()
  const { data: tpls } = await sb.from('templates').select('*').order('created_at', { ascending: false })
  return (
    <>
      <TemplateForm />
      <h3>Mẫu đã tải lên ({tpls?.length ?? 0})</h3>
      <div className="grid">{tpls?.map((t: any) => (
        <div className="card" key={t.id} style={{ opacity: t.active ? 1 : .55 }}>
          {t.preview_url ? <img src={t.preview_url} alt={t.name} style={{ width: '100%', borderRadius: 10, aspectRatio: '9/16', objectFit: 'cover' }} />
            : <div className="swatch" style={{ background: t.theme.bg, color: t.theme.ink, borderColor: t.theme.ac }}>{t.name}</div>}
          <b>{t.name}</b> <span className="tag">{t.tag}</span>
          <div className="acts">
            <form action={toggleTemplate}><input type="hidden" name="id" value={t.id} /><input type="hidden" name="active" value={String(!t.active)} /><button className="btn o sm">{t.active ? 'Ẩn' : 'Hiện'}</button></form>
            <form action={deleteTemplate}><input type="hidden" name="id" value={t.id} /><button className="btn o sm danger">Xóa</button></form>
          </div>
        </div>))}
      </div>
    </>
  )
}
