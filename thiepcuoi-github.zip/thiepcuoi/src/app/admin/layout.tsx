import Link from 'next/link'
import { requireAdmin } from '@/lib/auth'
export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  await requireAdmin()
  return (
    <main className="wrap">
      <nav className="nav"><Link href="/"><b>Thiệp Cưới</b></Link><span>Trang quản trị</span><Link className="btn o" href="/dashboard">← Thiệp của tôi</Link></nav>
      <div className="tabs">
        <Link className="chip" href="/admin">Tổng quan</Link>
        <Link className="chip" href="/admin/users">Tài khoản</Link>
        <Link className="chip" href="/admin/templates">Mẫu thiệp</Link>
      </div>
      {children}
    </main>
  )
}
