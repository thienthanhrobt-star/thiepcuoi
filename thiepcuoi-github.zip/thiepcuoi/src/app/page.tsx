import Link from 'next/link'
import { supabaseServer } from '@/lib/supabase/server'
export default async function Home() {
  const sb = await supabaseServer()
  const { data: { user } } = await sb.auth.getUser()
  return (
    <main className="wrap">
      <nav className="nav"><b>Thiệp Cưới</b><div>
        {user ? <Link className="btn" href="/dashboard">Thiệp của tôi</Link>
          : <><Link className="btn o" href="/dang-nhap">Đăng nhập</Link> <Link className="btn" href="/dang-ky">Đăng ký</Link></>}
      </div></nav>
      <section className="hero">
        <h1>Tạo thiệp cưới online<br />chỉ trong 5 phút</h1>
        <p>Chọn mẫu, điền thông tin và gửi cho mọi người qua một đường link.</p>
        <Link className="btn" href={user ? '/dashboard' : '/dang-ky'}>Đăng ký &amp; tạo thiệp miễn phí</Link>
      </section>
    </main>
  )
}
